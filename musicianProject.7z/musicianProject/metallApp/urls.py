from metallApp.views import metall_show_page
from django.urls import path


urlpatterns = [
    path('dance/', metall_show_page)
]
