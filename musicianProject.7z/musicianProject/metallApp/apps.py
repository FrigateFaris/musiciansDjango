from django.apps import AppConfig


class MetallappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'metallApp'
