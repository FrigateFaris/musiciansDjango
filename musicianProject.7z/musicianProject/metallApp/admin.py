from django.contrib import admin
from metallApp.models import MetallMusician

# Register your models here.
admin.site.register(MetallMusician)
