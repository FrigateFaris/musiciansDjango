from django.shortcuts import render


# Create your views here.
def metall_show_page(request):
    return render(request, 'metall.html')