from popApp.views import pop_show_page
from django.urls import path


urlpatterns = [
    path('dance/', pop_show_page)
]
