from django.shortcuts import render


# Create your views here.
def pop_show_page(request):
    return render(request, 'pop')
