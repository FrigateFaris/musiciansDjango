from django.contrib import admin
from popApp.models import PopMusician

# Register your models here.
admin.site.register(PopMusician)