from django.shortcuts import render


# Create your views here.
def main_show_page(request):
    return render(request, 'main.html')
