from django.contrib import admin
from danceApp.models import DanceMusician

# Register your models here.
admin.site.register(DanceMusician)

