from django.shortcuts import render


# Create your views here.
def dance_music_page(request):
    return render(request, 'dance.html')