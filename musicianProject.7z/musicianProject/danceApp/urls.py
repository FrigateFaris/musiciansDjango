from danceApp.views import dance_music_page
from django.urls import path


urlpatterns = [
    path('dance/', dance_music_page)
]
