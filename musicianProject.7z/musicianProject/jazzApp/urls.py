from jazzApp.views import jazz_show_page
from django.urls import path


urlpatterns = [
    path('jazz/', jazz_show_page)
]
