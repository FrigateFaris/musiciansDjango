from django.db import models


# Create your models here.
class JazzMusician(models.Model):
    name = models.CharField(max_length=20)
    age = models.IntegerField()
    instrument = models.CharField(max_length=70)
    born_place = models.CharField(max_length=40)
    popular_music = models.CharField(max_length=50)
    img = models.CharField(max_length=500, null=True)

    def __str__(self):
        return f'{self.name} - {self.age} - {self.instrument} - {self.born_place} - {self.popular_music}'

    def get_absolute_url(self):
        return f'{self.pk}'
