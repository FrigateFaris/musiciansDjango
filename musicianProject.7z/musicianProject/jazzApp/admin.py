from django.contrib import admin
from jazzApp.models import JazzMusician

# Register your models here.
admin.site.register(JazzMusician)
