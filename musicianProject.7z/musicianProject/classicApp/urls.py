from django.urls import path
from classicApp.views import classic_music_page

urlpatterns = [
    path('classic/', classic_music_page)
]
