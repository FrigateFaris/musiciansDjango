from django.shortcuts import render
from classicApp.models import ClassicMusician


# Create your views here.
def classic_music_page(request):
    musician = ClassicMusician.objects.all()
    context = {
        'musician': musician
    }
    return render(request, 'classic.html', context=context)
