from django.contrib import admin
from classicApp.models import ClassicMusician

# Register your models here.
admin.site.register(ClassicMusician)
